package jaynth.android.jumblemumble;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

import jaynth.android.jumblemumble.TimerThread;

public class GameScreen extends Activity 
{
	
	public static int time = 0;
	public final int max_time = 50;
	boolean thread = false;
	
	private Handler mainThreadHandler;
	
    public  TextView lblTime ;
    
	final Handler timeHandler = new Handler(){
		
		@Override
		public void handleMessage(Message msg)
		{
			lblTime.setText("Haaws");
			
		}
	};
	
	
       
  			
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
				try{
					super.onCreate(savedInstanceState);
					setContentView(R.layout.game_screen);
					lblTime = (TextView)findViewById(R.id.lblJumbleMumble);
					
					setMainThreadHandler(new Handler(){
						public void handleMessage(Message msg) {

							lblTime.setText("Rouse pasanga");

						}

					});
					
					final Thread timer = new Thread(new TimerThread(timeHandler) );
					timer.start();
				}
		catch(Exception e)
		{
			e.printStackTrace();
		}
				
	}
	
	
	@Override
	public void onStop()
	{
		super.onStop();
	}


	public void setMainThreadHandler(Handler mainThreadHandler) {
		this.mainThreadHandler = mainThreadHandler;
	}


	public Handler getMainThreadHandler() {
		return mainThreadHandler;
	}
	
}
