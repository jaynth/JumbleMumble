package jaynth.android.jumblemumble;

import android.os.Handler;
import android.os.Message;

public class TimerThread implements Runnable{
	
	private Handler mainThreadHandler;
	
	TimerThread(Handler mainHandler)
	{
		this.mainThreadHandler = mainHandler;
	}

	public void run() {
		
		Message msg = mainThreadHandler.obtainMessage();
		mainThreadHandler.sendMessage(msg);
				
	}
		
		
	}



